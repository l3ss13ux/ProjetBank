package fr.hsql;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Gestion des comptes.
 */
public class InitHsqlDb {
	private static final Logger LOG = LogManager.getLogger();

	private static final String FICHIER_SQL_CREATE = "create.sql";
	private static final String FICHIER_SQL_INSERT = "insert.sql";

	/**
	 * Va initialiser la base HSQL.
	 *
	 * @param args
	 *            les arguments.
	 */
	public static void main(String[] args) {
		InitHsqlDb.LOG.debug("-- Debut --");
		InitHsqlDb.LOG.warn("-- Ne pas oublier de  démarrer HSQL (fichier startdb.bat --");
		try {
			InitHsqlDb.LOG.debug("-- Chargement du driver");
			Class.forName("org.hsqldb.jdbc.JDBCDriver");
			InitHsqlDb.LOG.debug("-- Chargement du driver - OK");
		} catch (Exception e) {
			InitHsqlDb.LOG.fatal("Driver HSQL introuvable", e);
			System.exit(-1);
		}

		Connection connection = null;
		Statement statement = null;
		try {
			InitHsqlDb.LOG.debug("-- Ouverture de la connexion");
			connection = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/banque", "SA", "");
			InitHsqlDb.LOG.debug("-- Ouverture de la connexion - OK");

			InitHsqlDb.LOG.debug("-- Ouverture du statement");
			statement = connection.createStatement();
			InitHsqlDb.LOG.debug("-- Ouverture du statement - OK");

			InitHsqlDb.LOG.debug("-- Preparation des requetes create");
			String requetes = InitHsqlDb.loadRequetes(InitHsqlDb.FICHIER_SQL_CREATE);
			statement.executeQuery(requetes);
			InitHsqlDb.LOG.debug("-- Preparation des requetes create - OK");
			statement.close();

			InitHsqlDb.LOG.debug("-- Preparation des requetes insert");
			requetes = InitHsqlDb.loadRequetes(InitHsqlDb.FICHIER_SQL_INSERT);
			statement = connection.createStatement();
			statement.executeQuery(requetes);
			InitHsqlDb.LOG.debug("-- Preparation des requetes insert - OK");

		} catch (Exception e) {
			InitHsqlDb.LOG.error("Erreur lors de l'initialisation de la base", e);
		} finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					InitHsqlDb.LOG.error("Erreur lors de la fermeture du statement", e);
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					InitHsqlDb.LOG.error("Erreur lors de la fermeture de la base", e);
				}
			}
		}

		InitHsqlDb.LOG.debug("-- Fin --");
		System.exit(0);
	}

	/**
	 * Charge le fichier SQL qui contient les scripts d'initialisation de la base.
	 *
	 * @param fileName
	 *            a file name
	 * @return le contenu du fichier
	 * @throws IOException
	 *             si un probleme survient.
	 */
	private static String loadRequetes(String fileName) throws IOException {
		InitHsqlDb.LOG.debug("-- Ouverture du fichier {}", fileName);
		String resu = null;
		try (InputStream is = InitHsqlDb.class.getClassLoader().getResourceAsStream(fileName);
				InputStreamReader isr = new InputStreamReader(is);
				BufferedReader br = new BufferedReader(isr)) {
			StringBuffer sb = new StringBuffer();
			String ligne = null;
			while ((ligne = br.readLine()) != null) {
				sb.append(ligne).append("\n");
			}
			resu = sb.toString();
		}
		InitHsqlDb.LOG.debug("-- Ouverture du fichier {} - OK", fileName);
		InitHsqlDb.LOG.trace("-- Ouverture du fichier de requetes - {}", resu);
		return resu;
	}

}